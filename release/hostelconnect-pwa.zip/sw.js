// Lightweight service worker for offline + low-network usage + background sync for attendance writes
const CACHE_VERSION = 'v2';
const STATIC_CACHE = `static-${CACHE_VERSION}`;
const RUNTIME_CACHE = `runtime-${CACHE_VERSION}`;

const CORE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
  '/icons/icon-192.svg',
  '/icons/icon-512.svg',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => cache.addAll(CORE_ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => ![STATIC_CACHE, RUNTIME_CACHE].includes(k)).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Helper: classify requests
function isHTML(req) {
  return req.headers.get('accept')?.includes('text/html');
}
function isAPI(req) {
  const url = new URL(req.url);
  return url.pathname.startsWith('/attendance') || url.pathname.startsWith('/api');
}
function isAttendanceWrite(req) {
  if (req.method !== 'POST') return false;
  const url = new URL(req.url);
  return (
    url.pathname === '/attendance/mark' ||
    url.pathname === '/attendance/join' ||
    url.pathname === '/attendance/join-by-qr'
  );
}
function isStatic(req) {
  const url = new URL(req.url);
  return url.origin === self.location.origin && (url.pathname.startsWith('/assets/') || url.pathname.endsWith('.css') || url.pathname.endsWith('.js'));
}

self.addEventListener('sync', (event) => {
  if (event.tag === 'attendance-sync') {
    event.waitUntil(flushQueue());
  }
});

self.addEventListener('message', (event) => {
  if (event?.data?.type === 'FLUSH_ATTENDANCE_QUEUE') {
    event.waitUntil(flushQueue());
  }
  if (event?.data?.type === 'GET_ATTENDANCE_QUEUE_COUNT') {
    event.waitUntil((async () => {
      const items = await dbGetAll().catch(() => []);
      try {
        // Reply to the requesting client with the current count
        event?.source?.postMessage?.({ type: 'ATTENDANCE_QUEUE_COUNT', count: items.length || 0 });
      } catch (e) {}
    })());
  }
});

// Minimal IndexedDB helpers for request queue
function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('attn-queue', 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('outbox')) {
        db.createObjectStore('outbox', { keyPath: 'id', autoIncrement: true });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function dbAdd(item) {
  return openDB().then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction('outbox', 'readwrite');
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.objectStore('outbox').add(item);
  }));
}
function dbGetAll() {
  return openDB().then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction('outbox', 'readonly');
    const req = tx.objectStore('outbox').getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  }));
}
function dbDelete(id) {
  return openDB().then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction('outbox', 'readwrite');
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.objectStore('outbox').delete(id);
  }));
}

async function queueRequest(req) {
  try {
    const cloned = req.clone();
    const headers = {};
    cloned.headers.forEach((v, k) => {
      if (k.toLowerCase() === 'authorization' || k.toLowerCase() === 'content-type') headers[k] = v;
    });
    const bodyText = await cloned.text();
    await dbAdd({ url: cloned.url, method: cloned.method, headers, body: bodyText, createdAt: Date.now() });
    try { await self.registration.sync.register('attendance-sync'); } catch (e) {}
  } catch (e) {}
}

async function flushQueue() {
  try {
    const items = await dbGetAll();
    if (!items.length) return true;
    for (const item of items) {
      try {
        const res = await fetch(item.url, { method: item.method, headers: item.headers, body: item.body });
        if (res && res.ok) {
          await dbDelete(item.id);
        }
      } catch (e) {
        // network still down; re-register sync and stop early
        try { await self.registration.sync.register('attendance-sync'); } catch (e2) {}
        return false;
      }
    }
    return true;
  } catch (e) {
    return false;
  }
}

self.addEventListener('fetch', (event) => {
  const req = event.request;

  // Intercept attendance writes to queue offline operations
  if (isAttendanceWrite(req)) {
    event.respondWith((async () => {
      try {
        // Try network directly
        const res = await fetch(req.clone());
        return res;
      } catch (e) {
        // Queue and acknowledge as accepted for background sync
        await queueRequest(req);
        return new Response(JSON.stringify({ queued: true }), { status: 202, headers: { 'Content-Type': 'application/json' } });
      }
    })());
    return;
  }

  // Only handle GET to avoid interfering with other writes
  if (req.method !== 'GET') return;

  // HTML: Network-first with offline fallback
  if (isHTML(req)) {
    event.respondWith(
      fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(RUNTIME_CACHE).then((cache) => cache.put(req, copy));
        return res;
      }).catch(() => caches.match(req).then((res) => res || caches.match('/index.html')))
    );
    return;
  }

  // Static assets: Cache-first
  if (isStatic(req)) {
    event.respondWith(
      caches.match(req).then((cached) => cached || fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(STATIC_CACHE).then((cache) => cache.put(req, copy));
        return res;
      }))
    );
    return;
  }

  // APIs (GET): Stale-while-revalidate (low network usage)
  if (isAPI(req)) {
    event.respondWith(
      caches.match(req).then((cached) => {
        const fetchPromise = fetch(req).then((res) => {
          const copy = res.clone();
          caches.open(RUNTIME_CACHE).then((cache) => cache.put(req, copy));
          return res;
        }).catch(() => cached || Promise.reject('offline')); // use cache when offline
        return cached || fetchPromise;
      })
    );
    return;
  }

  // Default: pass-through
});
